export class Prof {
    idProf: number;
    nomProf: string;
    prenomProf: string;
    telProf: string;
}
